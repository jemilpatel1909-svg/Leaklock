# Example placeholder only
API_KEY = "replace-me-with-an-environment-variable"

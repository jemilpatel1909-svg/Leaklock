# LeakLock v1 🔐

A beginner-friendly MVP for detecting accidentally exposed secrets in uploaded code/files.

## Features
- Upload a ZIP archive from the web dashboard
- Scans text files recursively
- Detects common API keys, tokens, passwords, private keys, database URLs, and cloud credentials
- Masks the detected value in the UI
- Assigns severity and a risk score
- Download scan results as JSON
- No external API or AI required

## Requirements
- Python 3.10+
- pip

## Run on Windows
```powershell
cd leaklock_v1
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then open http://127.0.0.1:8000

## Run on macOS/Linux
```bash
cd leaklock_v1
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Notes
This is an MVP, not a complete security product. Never upload real production credentials to an untrusted development server. If a real secret is found, rotate/revoke it rather than only deleting it from the file.

from fastapi import FastAPI, Request, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import io
import json
import re
import zipfile
import uuid

BASE = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE / "templates"))

app = FastAPI(title="LeakLock v1", version="1.0.0")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

MAX_UPLOAD = 10 * 1024 * 1024
MAX_FILES = 500
MAX_FILE_SIZE = 2 * 1024 * 1024

# These are defensive detection rules. Values are masked in results.
PATTERNS = [
    ("Private Key", "CRITICAL", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    ("AWS Access Key", "CRITICAL", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GitHub Token", "CRITICAL", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b")),
    ("Google API Key", "HIGH", re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b")),
    ("Slack Token", "HIGH", re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{10,}\b")),
    ("JWT", "HIGH", re.compile(r"\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\b")),
    ("Database URL", "HIGH", re.compile(r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis)://[^\s'\"<>]+", re.I)),
    ("Password Assignment", "HIGH", re.compile(r"(?i)\b(?:password|passwd|pwd)\s*[:=]\s*['\"][^'\"]{6,}['\"]")),
    ("Secret Assignment", "HIGH", re.compile(r"(?i)\b(?:secret|client_secret|app_secret)\s*[:=]\s*['\"][^'\"]{8,}['\"]")),
    ("API Key Assignment", "MEDIUM", re.compile(r"(?i)\b(?:api[_-]?key|access[_-]?token|auth[_-]?token)\s*[:=]\s*['\"][^'\"]{8,}['\"]")),
    ("Firebase Key", "MEDIUM", re.compile(r"(?i)\bapiKey\s*[:=]\s*['\"][^'\"]{10,}['\"]")),
]

SEVERITY_WEIGHT = {"CRITICAL": 40, "HIGH": 25, "MEDIUM": 12, "LOW": 5}
ALLOWED_EXT = {
    ".py",".js",".ts",".jsx",".tsx",".java",".c",".cpp",".h",".hpp",".cs",".go",".rs",
    ".php",".rb",".swift",".kt",".kts",".json",".yaml",".yml",".toml",".ini",".cfg",
    ".conf",".env",".txt",".md",".html",".css",".sql",".sh",".ps1",".xml"
}
SKIP_NAMES = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build"}

def mask_value(value: str) -> str:
    value = value.strip()
    if len(value) <= 8:
        return "*" * len(value)
    return value[:4] + "*" * min(20, len(value) - 8) + value[-4:]

def line_number(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1

def scan_text(filename: str, text: str):
    findings = []
    seen = set()
    for kind, severity, pattern in PATTERNS:
        for match in pattern.finditer(text):
            line = line_number(text, match.start())
            key = (filename, kind, line)
            if key in seen:
                continue
            seen.add(key)
            value = match.group(0)
            findings.append({
                "file": filename,
                "line": line,
                "type": kind,
                "severity": severity,
                "match": mask_value(value),
                "recommendation": (
                    "Revoke/rotate the credential immediately, then remove it from source history."
                    if severity == "CRITICAL"
                    else "Move the secret to environment variables or a secret manager and remove it from source code."
                )
            })
    return findings

def risk_score(findings):
    score = min(100, sum(SEVERITY_WEIGHT.get(x["severity"], 1) for x in findings))
    if not findings:
        return 0
    return score

def scan_zip(raw: bytes):
    findings = []
    files_scanned = 0
    skipped = []
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            if len(infos) > MAX_FILES:
                raise HTTPException(400, f"ZIP contains more than {MAX_FILES} files.")
            for info in infos:
                parts = Path(info.filename).parts
                if any(p in SKIP_NAMES for p in parts):
                    continue
                if info.file_size > MAX_FILE_SIZE:
                    skipped.append(info.filename)
                    continue
                ext = Path(info.filename).suffix.lower()
                if ext not in ALLOWED_EXT:
                    skipped.append(info.filename)
                    continue
                data = z.read(info)
                try:
                    text = data.decode("utf-8", errors="ignore")
                except Exception:
                    continue
                files_scanned += 1
                findings.extend(scan_text(info.filename, text))
    except zipfile.BadZipFile:
        raise HTTPException(400, "Please upload a valid ZIP file.")
    return findings, files_scanned, skipped

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/scan")
async def scan(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(400, "LeakLock v1 currently accepts ZIP files only.")
    raw = await file.read()
    if len(raw) > MAX_UPLOAD:
        raise HTTPException(400, "ZIP is larger than the 10 MB MVP limit.")
    findings, files_scanned, skipped = scan_zip(raw)
    result = {
        "scan_id": str(uuid.uuid4()),
        "filename": file.filename,
        "files_scanned": files_scanned,
        "skipped_files": skipped,
        "finding_count": len(findings),
        "risk_score": risk_score(findings),
        "status": "CRITICAL" if any(x["severity"]=="CRITICAL" for x in findings)
                  else "HIGH" if any(x["severity"]=="HIGH" for x in findings)
                  else "CLEAN" if not findings else "MEDIUM",
        "findings": findings,
    }
    return JSONResponse(result)

@app.get("/health")
async def health():
    return {"status": "ok", "product": "LeakLock", "version": "1.0.0"}
